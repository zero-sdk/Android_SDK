package com.zcoup.adsdk.example.fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.zcoup.adsdk.example.MainActivity;
import com.zcoup.adsdk.example.R;
import com.zcoup.adsdk.example.config.Config;
import com.zcoup.appwall.ZcoupAppwall;
import com.zcoup.base.core.ZcoupSDK;

public class AppWallFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_appwall, null);
        initView(view);
        return view;
    }


    private void initView(View view) {

        view.findViewById(R.id.init_appwall).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ZcoupAppwall.preloadAppwall(getContext(), Config.slotIdAppWall);

            }
        });

        view.findViewById(R.id.show_appwall_new_activity)
                .setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if (!ZcoupSDK.isInitialized()) {
                            Toast.makeText(view.getContext(), "No initialization, please call the initialize function.",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }

                        //Optional
                        com.zcoup.appwall.CustomizeColor custimozeColor = new com.zcoup.appwall.CustomizeColor();
                        custimozeColor.setMainThemeColor(Color.parseColor("#ff0000ff"));
                        ZcoupAppwall.setThemeColor(custimozeColor);

                        //Optional
                        ZcoupAppwall.setActivityAnimation(R.anim.fade_in, R.anim.fade_out);
                        ZcoupAppwall.showAppwall(getContext(), Config.slotIdAppWall);

                    }
                });

        view.findViewById(R.id.show_appwall_natvie_fragment)
                .setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if (!ZcoupSDK.isInitialized()) {
                            Toast.makeText(view.getContext(), "No initialization, please call the initialize function.",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }
                        //Optional
                        com.zcoup.appwall.CustomizeColor custimozeColor = new com.zcoup.appwall.CustomizeColor();
                        custimozeColor.setMainThemeColor(Color.parseColor("#ffff0000"));
                        ZcoupAppwall.setThemeColor(custimozeColor);

                        android.app.Fragment fragment = ZcoupAppwall.getAppwallFragment(getContext(),
                                Config.slotIdAppWall);
                        ((MainActivity) getActivity()).showNativeFragment(fragment);
                    }
                });

    }

}
