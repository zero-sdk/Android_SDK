package com.zcoup.adsdk.example;

/**
 * Created by Vincent
 *
 */
public class AdHolder {
    public static com.zcoup.base.vo.AdsNativeVO adNativeVO = null;

}
