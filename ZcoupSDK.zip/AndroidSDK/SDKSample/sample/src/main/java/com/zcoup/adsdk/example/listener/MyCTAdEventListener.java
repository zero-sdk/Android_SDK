package com.zcoup.adsdk.example.listener;

import android.util.Log;
import android.widget.Toast;

import com.zcoup.base.callback.AdEventListener;

public class MyCTAdEventListener extends AdEventListener {

    @Override
    public void onReceiveAdSucceed(com.zcoup.base.core.ZCNative result) {
        showMsg("onReceiveAdSucceed");
    }

    @Override
    public void onReceiveAdVoSucceed(com.zcoup.base.vo.AdsNativeVO result) {
        showMsg("onReceiveAdVoSucceed");
    }

    @Override
    public void onInterstitialLoadSucceed(com.zcoup.base.core.ZCNative result) {
        showMsg("onInterstitialLoadSucceed");
    }

    @Override
    public void onReceiveAdFailed(com.zcoup.base.core.ZCNative result) {
        showMsg(result.getErrorsMsg());
        Log.i("sdksample", "==error==" + result.getErrorsMsg());
    }

    @Override
    public void onLandpageShown(com.zcoup.base.core.ZCNative result) {
        showMsg("onLandpageShown");
    }

    @Override
    public void onAdClicked(com.zcoup.base.core.ZCNative result) {
        showMsg("onAdClicked");
    }

    @Override
    public void onAdClosed(com.zcoup.base.core.ZCNative result) {
        showMsg("onAdClosed");
    }


    private void showMsg(String msg) {
        showToast(msg);
    }


    public static void showToast(String text) {
        // Toast.makeText(SampleApplication.context, text, Toast.LENGTH_SHORT).show();
    }


    private static Toast toast;

}
