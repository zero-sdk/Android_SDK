package com.zcoup.adsdk.example.config;

public class Config {

    public static String slotIdBanner = "39743648";
    public static String slotIdInterstitial = "96322343";
    public static String slotIdNative = "35244653";
    public static String slotIdAppWall = "83278441";
    public static String slotIdMutilAds = "35244653";
    public static String slotIdReward = "78434557";
    public static String slotIdNativeVideo = "28433442";

}
