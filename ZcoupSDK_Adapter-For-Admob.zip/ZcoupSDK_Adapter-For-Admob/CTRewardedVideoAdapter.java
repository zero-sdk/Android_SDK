package com.zcoup.mediation.admob;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.mediation.MediationRewardedVideoAdAdapter;
import com.google.android.gms.ads.reward.mediation.MediationRewardedVideoAdListener;
import com.zcoup.base.callback.VideoAdLoadListener;
import com.zcoup.base.core.ZCError;
import com.zcoup.base.core.ZCVideo;
import com.zcoup.base.core.ZcoupSDK;
import com.zcoup.video.core.RewardedVideoAdListener;
import com.zcoup.video.core.ZcoupVideo;

public class CTRewardedVideoAdapter implements MediationRewardedVideoAdAdapter {

    private static final String TAG = "CTRewardedVideoAdapter";

    private static String slotId = "";

    private MediationRewardedVideoAdListener mAdmobListener;
    private Context context;

    private ZCVideo zcVideo;

    private boolean isInitialized;


    @Override
    public void initialize(Context context,
                           MediationAdRequest mediationAdRequest,
                           String unUsed,
                           MediationRewardedVideoAdListener listener,
                           Bundle serverParameters,
                           Bundle mediationExtras) {
        Log.e(TAG, "initialize: serverParameters -> " + serverParameters);
        mAdmobListener = listener;
        slotId = serverParameters.getString("parameter");
        ZcoupSDK.initialize(context, slotId);
        if (!(context instanceof Activity)) {
            Log.w("  ZcoupAdapter", "Context must be of type Activity.");
            listener.onInitializationFailed(
                CTRewardedVideoAdapter.this, AdRequest.ERROR_CODE_INVALID_REQUEST);
            return;
        }
        this.context = context;
        mAdmobListener.onInitializationSucceeded(
            CTRewardedVideoAdapter.this);
        isInitialized = true;
    }


    @Override
    public void loadAd(MediationAdRequest mediationAdRequest, Bundle bundle, Bundle bundle1) {
        if (mAdmobListener != null) {
            ZcoupVideo.preloadRewardedVideo(context, slotId, loadListener);
        }
    }


    @Override
    public void showVideo() {
        ZcoupVideo.showRewardedVideo(zcVideo, cloudRVListener);
    }


    @Override
    public boolean isInitialized() {
        return isInitialized;
    }


    @Override
    public void onDestroy() {

    }


    @Override
    public void onPause() {
    }


    @Override
    public void onResume() {

    }


    private VideoAdLoadListener loadListener = new VideoAdLoadListener() {
        @Override
        public void onVideoAdLoadSucceed(ZCVideo video) {
            if (video != null) {
                zcVideo = video;
                mAdmobListener.onAdLoaded(CTRewardedVideoAdapter.this);
                return;
            }
            mAdmobListener.onAdFailedToLoad(CTRewardedVideoAdapter.this,
                Integer.parseInt(ZCError.ERR_CODE_VIDEO));
        }


        @Override
        public void onVideoAdLoadFailed(ZCError error) {
            mAdmobListener.onAdFailedToLoad(CTRewardedVideoAdapter.this,
                Integer.parseInt(ZCError.ERR_CODE_VIDEO));
        }

    };

    private RewardedVideoAdListener cloudRVListener = new RewardedVideoAdListener() {

        @Override
        public void videoStart() {
            if (mAdmobListener != null) {
                mAdmobListener.onAdOpened(CTRewardedVideoAdapter.this);
                mAdmobListener.onVideoStarted(CTRewardedVideoAdapter.this);
            }
        }


        @Override
        public void videoFinish() {

        }


        @Override
        public void videoError(Exception e) {
            if (mAdmobListener != null) {
                mAdmobListener.onAdFailedToLoad(
                    CTRewardedVideoAdapter.this, Integer.parseInt(ZCError.ERR_CODE_VIDEO));
            }
        }


        @Override
        public void videoClosed() {
            if (mAdmobListener != null) {
                mAdmobListener.onAdClosed(CTRewardedVideoAdapter.this);
            }
        }


        @Override
        public void videoClicked() {
            if (mAdmobListener != null) {
                mAdmobListener.onAdClicked(CTRewardedVideoAdapter.this);
            }
        }


        @Override
        public void videoRewarded(final String rewardName, final String rewardAmount) {
            if (mAdmobListener != null) {
                mAdmobListener.onRewarded(CTRewardedVideoAdapter.this, new RewardItem() {
                    @Override
                    public String getType() {
                        return rewardName;
                    }


                    @Override
                    public int getAmount() {
                        int amount = 0;
                        try {
                            amount = Integer.parseInt(rewardAmount);
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                        }
                        return amount;
                    }
                });
            }
        }

    };
}
