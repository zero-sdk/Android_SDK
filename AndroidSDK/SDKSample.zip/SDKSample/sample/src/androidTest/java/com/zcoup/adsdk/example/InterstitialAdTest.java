package com.zcoup.adsdk.example;

import android.app.Instrumentation;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import androidx.test.InstrumentationRegistry;
import androidx.test.espresso.DataInteraction;
import androidx.test.espresso.FailureHandler;
import androidx.test.espresso.IdlingPolicies;
import androidx.test.espresso.IdlingRegistry;
import androidx.test.espresso.intent.rule.IntentsTestRule;
import androidx.test.filters.LargeTest;
import androidx.test.rule.ActivityTestRule;
import androidx.test.runner.AndroidJUnit4;

import com.zcoup.adsdk.example.utils.Constants;
import com.zcoup.adsdk.example.utils.RepeatRule;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.TimeUnit;

import static androidx.test.espresso.Espresso.onData;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.Espresso.openActionBarOverflowOrOptionsMenu;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withClassName;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.anything;
import static org.hamcrest.Matchers.endsWith;

/**
 * Created by tujiantao on 2018/3/5.
 */
@LargeTest
@RunWith(AndroidJUnit4.class)
public class InterstitialAdTest {

    private final static String TAG = "InterstitialAdTest";

    @Rule
    public RepeatRule repeatRule = new RepeatRule();

    @Rule
    public ActivityTestRule<MainActivity> mActivityTestRule = new ActivityTestRule<>(MainActivity
        .class);

    @Rule
    public IntentsTestRule<com.zcoup.base.view.InterstitialActivity> interstitialActivityTestRule = new IntentsTestRule<>(com.zcoup.base.view.InterstitialActivity.class);

    private SimpleCountingIdlingResource getAdIdlingResource;

    private MainActivity activity;

    private Instrumentation instrumentation;

    @BeforeClass
    public static void startClass(){
        IdlingPolicies.setMasterPolicyTimeout(20, TimeUnit.SECONDS);
        IdlingPolicies.setIdlingResourceTimeout(20, TimeUnit.SECONDS);
    }

    @Before
    public void start() throws InterruptedException {
        instrumentation=InstrumentationRegistry.getInstrumentation();
//        UiDevice.getInstance(instrumentation).runWatchers();
//        PermissionsUtil.checkDialog();
        activity = mActivityTestRule.getActivity();

        //        if (!PowersUtil.getScreenOn(activity) || PowersUtil.getLockScreenOn(activity)) {//解锁屏幕
        //            PowersUtil.wakeUpAndUnlock(activity);
        //        }
        Thread.sleep(2000);
        //点击横竖屏
        openActionBarOverflowOrOptionsMenu(InstrumentationRegistry.getTargetContext());
        onView(withText("hvScreen")).perform(click());

        //点击进入插屏广告
        DataInteraction appCompatTextView = onData(anything())
            .inAdapterView(allOf(withId(R.id.listView),
                childAtPosition(withId(R.id.main_content), 0))).atPosition(1);
        appCompatTextView.perform(click());
    }

    @Test
    @RepeatRule.Repeat( runCount =  Constants.TEST_COUNT )
    public void loadAdSuccess() {
        getAdIdlingResource = SimpleCountingIdlingResource.create("test2");
        IdlingRegistry.getInstance().register(getAdIdlingResource);
        Log.i(TAG, "threadId=" + Thread.currentThread().getId() + ",processName=" + Thread
            .currentThread().getName());
        Log.i(TAG, "LOAD AD SUCCESS 点击前");
        onView(allOf(withId(R.id.loadButton),withText("LOAD AD"))).perform(click());
        Log.i(TAG, "LOAD AD SUCCESS");
        sleep(4000L);
        onView(withClassName(endsWith("WebView")))
            .check(matches(isDisplayed())).withFailureHandler(new FailureHandler() {
            @Override
            public void handle(Throwable error, Matcher<View> viewMatcher) {
                System.out.print("校验不合格 error="+error.getMessage()+",viewMatcher="+viewMatcher.toString());
                throw new RuntimeException(error);
            }
        });

    }


    @After
    public void stop() {
        IdlingRegistry.getInstance().unregister(getAdIdlingResource);
    }

    private void sleep(Long time){
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static Matcher<View> childAtPosition(
        final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                    && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }

}