//package com.zcoup.adsdk.example.utils;
//
//import android.support.test.InstrumentationRegistry;
//import android.support.test.uiautomator.UiDevice;
//import android.support.test.uiautomator.UiObject;
//import android.support.test.uiautomator.UiObjectNotFoundException;
//import android.support.test.uiautomator.UiSelector;
//
///**
// * Created by jiantao.tu on 2018/7/24.
// */
//public class PermissionsUtil {
//
//    public static void checkDialog(){
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        UiDevice device=UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
//        UiObject allowPermissions = device.findObject(new UiSelector().textMatches("是|确定|确定|Y|OK|Allow|Agree"));
//        if(allowPermissions!=null && allowPermissions.exists()){
//            try {
//                allowPermissions.click();
//            } catch (UiObjectNotFoundException e) {
//                e.printStackTrace();
//            }
//            checkDialog();
//        }
//    }
//}