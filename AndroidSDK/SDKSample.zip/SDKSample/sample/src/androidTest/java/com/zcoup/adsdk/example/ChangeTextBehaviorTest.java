package com.zcoup.adsdk.example;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

import androidx.core.content.ContextCompat;
import androidx.test.InstrumentationRegistry;
import androidx.test.filters.LargeTest;
import androidx.test.runner.AndroidJUnit4;

import com.zcoup.base.utils.Utils;
import com.zcoup.base.utils.gp.GpsHelper;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

@RunWith(AndroidJUnit4.class)
@LargeTest
public class ChangeTextBehaviorTest {

    private static final String stringToBeTyped = "Espresso";

//    @Rule
//    public ActivityTestRule<MainActivity> activityRule =
//            new ActivityTestRule<>(MainActivity.class);

    @Test
    public void changeText_sameActivity() {
        // Type text and then press the button.
//        onView(withId(R.id.editTextUserInput))
//                .perform(typeText(stringToBeTyped), closeSoftKeyboard());
//        onView(withId(R.id.changeTextBt)).perform(click());
//
//        // Check that the text was changed.
//        onView(withId(R.id.textToBeChanged))
//                .check(matches(withText(stringToBeTyped)));
        Context context = InstrumentationRegistry.getContext();

        Locale locale = context.getResources().getConfiguration().locale;

        String language = locale.getLanguage();


        String country = locale.getCountry();

        String lang = locale.getDisplayLanguage();


        Log.e("tjt852", "country=" + country);


        Log.e("tjt852", "ro.product.locale=" + language);


        Log.e("tjt852", "lang=" + lang);

        TimeZone tz = TimeZone.getDefault();
        String s = "TimeZone   " + tz.getDisplayName(false, TimeZone.SHORT) + " Timezon id :: " + tz.getID();
        Log.e("tjt852", s);
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);

        Log.e("tjt852", "gsm.sim.operator.alpha=" + telephonyManager.getSimOperatorName());

        Log.e("tjt852", "isGaidWithGps=" + GpsHelper.isGaidWithGps());

        DisplayMetrics v1 = new DisplayMetrics();
        ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getMetrics(v1);
        int size = context.getResources().getConfiguration().screenLayout & 15;
        Log.e("tjt852", "size=" + String.valueOf(size));
        Log.e("tjt852", "xdp=" + String.valueOf(v1.xdpi));
        Log.e("tjt852", "ydp=" + String.valueOf(v1.ydpi));

        Log.e("tjt852", "network=" + Utils.getNetworkState(context));

        SensorManager sm = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        List<Sensor> sensorList = sm.getSensorList(Sensor.TYPE_ALL);
        Log.e("tjt852", "sensors=" + sensorList.toString());
//        Sensor sensor = sensorList.get(0);
//        String getName = sensor.getName();//名称
//        int getFifoMaxEventCount = sensor.getFifoMaxEventCount();//名称
//        int getFifoReservedEventCount = sensor.getFifoReservedEventCount();//名称
//        int getHighestDirectReportRateLevel = sensor.getHighestDirectReportRateLevel();//名称
//        int getId = sensor.getId();//名称
//        int getMaxDelay = sensor.getMaxDelay();//名称
//        float getMaximumRange = sensor.getMaximumRange();//名称
//        int getMinDelay = sensor.getMinDelay();//名称
//        float getPower = sensor.getPower();//名称
//        int getReportingMode = sensor.getReportingMode();//名称
//        float getResolution = sensor.getResolution();//名称
//        String getStringType = sensor.getStringType();//名称
//        int getType = sensor.getType();//名称
//        String getVendor = sensor.getVendor();//厂商
//        int getVersion = sensor.getVersion();//版本号
//        Log.e("tjt852", "sensors   getName=" + getName + ",getFifoMaxEventCount=" + getFifoMaxEventCount + ",getFifoReservedEventCount=" + getFifoReservedEventCount
//                + ",getHighestDirectReportRateLevel=" + getHighestDirectReportRateLevel + ",getId=" + getId + ",getMaxDelay=" + getMaxDelay + ",getMaximumRange=" + getMaximumRange
//                + ",getMinDelay=" + getMinDelay + ",getPower=" + getPower + ",getReportingMode=" + getReportingMode + ",getResolution=" + getResolution + ",getStringType=" + getStringType
//                + "，getType=" + getType + ",getVendor=" + getVendor + ",getVersion=" + getVersion);


        BluetoothAdapter blueAdapter = BluetoothAdapter.getDefaultAdapter();
        boolean isEnabled = blueAdapter.isEnabled();
        Log.e("tjt852", "blueIsEnabled=" + isEnabled);

        int simState = telephonyManager.getSimState();

        String simStateStr = "";
        switch (simState) {
            case TelephonyManager.SIM_STATE_UNKNOWN:
                simStateStr = "UNKNOWN";
                break;
            case TelephonyManager.SIM_STATE_ABSENT:
                simStateStr = "ABSENT";
                break;
            case TelephonyManager.SIM_STATE_PIN_REQUIRED:
                simStateStr = "PIN_REQUIRED";
                break;
            case TelephonyManager.SIM_STATE_PUK_REQUIRED:
                simStateStr = "PUK_REQUIRED";
                break;
            case TelephonyManager.SIM_STATE_NETWORK_LOCKED:
                simStateStr = "NETWORK_LOCKED";
                break;
            case TelephonyManager.SIM_STATE_READY:
                simStateStr = "READY";
                break;
            case TelephonyManager.SIM_STATE_NOT_READY:
                simStateStr = "NOT_READY";
                break;
            case TelephonyManager.SIM_STATE_PERM_DISABLED:
                simStateStr = "PERM_DISABLED";
                break;
            case TelephonyManager.SIM_STATE_CARD_IO_ERROR:
                simStateStr = "CARD_IO_ERROR";
                break;
            case TelephonyManager.SIM_STATE_CARD_RESTRICTED:
                simStateStr = "CARD_RESTRICTED";
                break;
        }
        Log.e("tjt852", "gsm.sim.state=" + simStateStr);


        Log.e("tjt852", "gsm.sim.operator.numeric=" + telephonyManager.getSimOperator());

        Log.e("tjt852", "gsm.sim.operator.iso-country=" + telephonyManager.getSimCountryIso());

        Log.e("tjt852", "gsm.operator.alphac=" + telephonyManager.getNetworkOperatorName());

        Log.e("tjt852", "gsm.operator.numeric=" + telephonyManager.getNetworkOperator());

        Log.e("tjt852", "gsm.operator.iso-country=" + telephonyManager.getNetworkCountryIso());

        Log.e("tjt852", "last_boot_time=" + android.os.SystemClock.elapsedRealtime());

        Log.e("tjt852", "last_boot_time=" + android.os.SystemClock.elapsedRealtime());

        // 使用
        Location location = getLastKnownLocation(context);
        if (location != null) {
            double latitude = location.getLatitude();//经度
            double longitude = location.getLongitude();//纬度
            double altitude = location.getAltitude();//海拔
            float speed = location.getSpeed();//速度
            float bearing = location.getBearing();//方向
            Log.e("tjt852", "gps.longitude=" + longitude);

            Log.e("tjt852", "gps.latitude=" + latitude);

            Log.e("tjt852", "gps.altitude=" + altitude);

            Log.e("tjt852", "gps.speed=" + speed);

            Log.e("tjt852", "gps.bearing=" + bearing);
        }

        try {
            IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent receiver = context.registerReceiver(null, filter);
            if (receiver != null) {
                int level = receiver.getIntExtra("level", 0);//获取当前电量
                int status = receiver.getIntExtra("status", 0);//获取充电状态
                int voltage = receiver.getIntExtra("voltage", 0);//获取电压(mv)
                int temperature = receiver.getIntExtra("temperature", 0);//获取温度(数值)
                double t = temperature / 10.0;  //运算转换,电池摄氏温度，默认获取的非摄氏温度值

                Log.e("tjt852", "battery.capacity:" + level + "%");
                Log.e("tjt852", "battery.status:" + status);
                Log.e("tjt852", "battery.voltage_now:" + voltage);
                Log.e("tjt852", "battery.temp:" + t);
            }

        } catch (Throwable e) {
            e.printStackTrace();
        }

    }


    private Location getLastKnownLocation(Context context) {
        //获取地理位置管理器
        LocationManager mLocationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO:去请求权限后再获取
            return null;
        }
        List<String> providers = mLocationManager.getProviders(true);
        Location bestLocation = null;
        for (String provider : providers) {
            Location l = mLocationManager.getLastKnownLocation(provider);
            if (l == null) {
                continue;
            }
            if (bestLocation == null || l.getAccuracy() < bestLocation.getAccuracy()) {
                bestLocation = l;
            }
        }
// 在一些手机5.0(api21)获取为空后，采用下面去兼容获取。
        if (bestLocation == null) {
            Criteria criteria = new Criteria();
            criteria.setAccuracy(Criteria.ACCURACY_COARSE);
            criteria.setAltitudeRequired(false);
            criteria.setBearingRequired(false);
            criteria.setCostAllowed(true);
            criteria.setPowerRequirement(Criteria.POWER_LOW);
            String provider = mLocationManager.getBestProvider(criteria, true);
            if (!TextUtils.isEmpty(provider)) {
                assert provider != null;
                bestLocation = mLocationManager.getLastKnownLocation(provider);
            }
        }
        return bestLocation;
    }


}
