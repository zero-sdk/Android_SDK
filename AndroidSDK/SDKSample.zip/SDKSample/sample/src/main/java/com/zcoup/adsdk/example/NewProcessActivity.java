package com.zcoup.adsdk.example;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.zcoup.adsdk.example.config.Config;
import com.zcoup.adsdk.example.listener.MyCTAdEventListener;
import com.facebook.drawee.view.SimpleDraweeView;
import com.zcoup.appwall.ZcoupAppwall;
import com.zcoup.base.core.ZCNative;
import com.zcoup.base.core.ZcoupSDK;
import com.zcoup.base.utils.ZCLog;

/**
 * Created by huangdong on 17/7/17.
 */

public class NewProcessActivity extends Activity {

    private ViewGroup container;
    private ViewGroup adLayout;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_process);

        ZcoupSDK.adSourceType = "ct";

        loadNativeAd();

        loadInterstitial();

        loadAppwall();

    }

    private void loadInterstitial() {

        findViewById(R.id.bt2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ZcoupSDK.preloadInterstitialAd(NewProcessActivity.this, Config.slotIdInterstitial,
                        new MyCTAdEventListener() {

                            @Override
                            public void onShowSucceed(ZCNative result) {
                                super.onShowSucceed(result);
                            }


                            @Override
                            public void onReceiveAdSucceed(ZCNative result) {              //在广告加载成功之后再show,不然会出一个空白
                                if (result != null && result.isLoaded()) {
                                    ZcoupSDK.showInterstitialAd(result);

                                }

                                super.onReceiveAdSucceed(result);
                            }
                        });
            }
        });


    }


    private void loadNativeAd() {

        container = (ViewGroup) findViewById(R.id.container);                                             //媒体容器
        adLayout = (ViewGroup) View.inflate(SampleApplication.context, R.layout.advance_native_layout, null);  //广告布局

        findViewById(R.id.bt1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                loadAd();
            }
        });

    }


    public void loadAd() {
        // 获取原生广告，返回一个含有广告的容器
        ZcoupSDK.getNativeAd(Config.slotIdNative, SampleApplication.context, new MyCTAdEventListener() {
            @Override
            public void onReceiveAdSucceed(com.zcoup.base.core.ZCNative result) {
                if (result == null) {
                    return;
                }
                ZCLog.e("onReceiveAdSucceed");
                com.zcoup.base.core.ZCAdvanceNative ctAdvanceNative = (com.zcoup.base.core.ZCAdvanceNative) result;
                showAd(ctAdvanceNative);
                super.onReceiveAdSucceed(result);

            }


            @Override
            public void onReceiveAdFailed(com.zcoup.base.core.ZCNative result) {
                ZCLog.e("onReceiveAdFailed");
                super.onReceiveAdFailed(result);
            }


            @Override
            public void onAdClicked(com.zcoup.base.core.ZCNative result) {
                ZCLog.e("onAdClicked");
                super.onAdClicked(result);
            }

        });
    }


    private void showAd(final com.zcoup.base.core.ZCAdvanceNative ctAdvanceNative) {
        SimpleDraweeView img = (SimpleDraweeView) adLayout.findViewById(R.id.iv_img);
        SimpleDraweeView icon = (SimpleDraweeView) adLayout.findViewById(R.id.iv_icon);
        TextView title = (TextView) adLayout.findViewById(R.id.tv_title);
        TextView desc = (TextView) adLayout.findViewById(R.id.tv_desc);
        TextView click = (TextView) adLayout.findViewById(R.id.bt_click);
        SimpleDraweeView ad_choice_icon = (SimpleDraweeView) adLayout.findViewById(
                R.id.ad_choice_icon);

        img.setImageURI(Uri.parse(ctAdvanceNative.getImageUrl()));
        icon.setImageURI(Uri.parse(ctAdvanceNative.getIconUrl()));
        title.setText(ctAdvanceNative.getTitle());
        desc.setText(ctAdvanceNative.getDesc());
        click.setText(ctAdvanceNative.getButtonStr());
        ad_choice_icon.setImageURI(ctAdvanceNative.getAdChoiceIconUrl());

//        ctAdvanceNative.addADLayoutToADContainer(adLayout);
        ctAdvanceNative.registeADClickArea(adLayout);

        container.removeAllViews();
//        container.addView(ctAdvanceNative);
        container.addView(adLayout);
    }


    private void loadAppwall() {

        findViewById(R.id.bt3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ZcoupAppwall.showAppwall(SampleApplication.context, Config.slotIdAppWall);

            }
        });


    }


}
