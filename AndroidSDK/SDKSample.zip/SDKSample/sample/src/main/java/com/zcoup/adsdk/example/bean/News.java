package com.zcoup.adsdk.example.bean;

import com.zcoup.video.core.ZCNativeVideo;

/**
 * Created by huangdong on 16/8/18.
 */
public class News {

    public ZCNativeVideo ctNativeVideo;
    public com.zcoup.base.core.ZCAdvanceNative ctAdvanceNative;
    public String iconUrl;
    public String title;
    public String desc;
    public String choiceUrl;
    public String buttonStr;
    public boolean isAds = false;

}
