package com.zcoup.adsdk.example.fragment;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.facebook.drawee.view.SimpleDraweeView;
import com.zcoup.adsdk.example.R;
import com.zcoup.adsdk.example.SampleApplication;
import com.zcoup.adsdk.example.config.Config;
import com.zcoup.adsdk.example.listener.MyCTAdEventListener;
import com.zcoup.base.core.ZCAdvanceNative;
import com.zcoup.base.core.ZCNative;
import com.zcoup.base.core.ZcoupSDK;
import com.zcoup.base.utils.ZCLog;
import com.zcoup.base.vo.AdsVO;

public class AdvanceAdFragment extends Fragment {

    private ViewGroup container;
    private ViewGroup adLayout;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_advance_native, null);
        initView(view);
        return view;
    }

    private final static String TAG = "AdvanceAdTest";

    private void initView(View view) {
        container = view.findViewById(R.id.container);                         //媒体容器

        view.findViewById(R.id.load_ad).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadAd();
                Log.i(TAG, "loadAd");
            }
        });


        view.findViewById(R.id.load_for_cache).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                loadAdForCache();
                Log.i(TAG, "loadAdForCache");

            }
        });

        view.findViewById(R.id.show_from_cache).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getAdFromCacheAndShow();
                Log.i(TAG, "getAdFromCacheAndShow");

            }
        });

    }

    public void loadAd() {
        adLayout = (ViewGroup) View.inflate(SampleApplication.context, R.layout.advance_native_layout, null);  //广告布局

        ZcoupSDK.getNativeAd(Config.slotIdNative, SampleApplication.context, new MyCTAdEventListener() {

            @Override
            public void onReceiveAdSucceed(ZCNative result) {
                if (result == null) {
                    return;
                }
                ZCAdvanceNative ctZCAdvanceNative = (ZCAdvanceNative) result;
                showAd(ctZCAdvanceNative);
                ZCLog.e("onReceiveAdSucceed");
                super.onReceiveAdSucceed(result);
            }


            @Override
            public void onReceiveAdFailed(ZCNative result) {
                ZCLog.e("onReceiveAdFailed");
                super.onReceiveAdFailed(result);
            }


            @Override
            public void onAdClicked(ZCNative result) {
                ZCLog.e("onAdClicked");
                super.onAdClicked(result);
            }

        });

    }

    private void loadAdForCache() {
        ZcoupSDK.preloadNativeAd(Config.slotIdNative, getContext());
    }

    public void getAdFromCacheAndShow() {
        adLayout = (ViewGroup) View.inflate(SampleApplication.context, R.layout.advance_native_layout, null);  //广告布局

        ZcoupSDK.getNativeAdForCache(Config.slotIdNative, new MyCTAdEventListener() {
            @Override
            public void onReceiveAdSucceed(ZCNative result) {
                if (result == null) return;
                ZCAdvanceNative ctZCAdvanceNative = (ZCAdvanceNative) result;

                showAd(ctZCAdvanceNative);
            }

            @Override
            public void onReceiveAdVoSucceed(AdsVO result) {
                final ZCAdvanceNative advanceNative = new ZCAdvanceNative(getContext());
                advanceNative.setNativeVO(result);
                super.onReceiveAdVoSucceed(result);
            }
        });

    }

    private void showAd(final ZCAdvanceNative ctZCAdvanceNative) {

        SimpleDraweeView img = adLayout.findViewById(R.id.iv_img);
        SimpleDraweeView icon = adLayout.findViewById(R.id.iv_icon);
        TextView title = adLayout.findViewById(R.id.tv_title);
        TextView desc = adLayout.findViewById(R.id.tv_desc);
        TextView click = adLayout.findViewById(R.id.bt_click);
        SimpleDraweeView ad_choice_icon = adLayout.findViewById(R.id.ad_choice_icon);

        if (ctZCAdvanceNative.getImageFile() == null) {
            //if no cache, get image from url
            img.setImageURI(Uri.parse(ctZCAdvanceNative.getImageUrl()));
        } else {
            //loaded from cache
            img.setImageURI(Uri.fromFile(ctZCAdvanceNative.getImageFile()));
        }

        if (ctZCAdvanceNative.getIconFile() == null) {
            icon.setImageURI(Uri.parse(ctZCAdvanceNative.getIconUrl()));
        } else {
            //loaded from cache
            icon.setImageURI(Uri.fromFile(ctZCAdvanceNative.getIconFile()));
        }

        title.setText(ctZCAdvanceNative.getTitle());
        desc.setText(ctZCAdvanceNative.getDesc());
        click.setText(ctZCAdvanceNative.getButtonStr());
        ad_choice_icon.setImageURI(ctZCAdvanceNative.getAdChoiceIconUrl());

        container.removeAllViews();

        //只是注册点击区域,调此处设置
        ctZCAdvanceNative.registeADClickArea(adLayout);
        container.addView(adLayout);

        ad_choice_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String linkUrl = ctZCAdvanceNative.getAdChoiceLinkUrl();
                if (TextUtils.isEmpty(linkUrl)) {
                    Toast.makeText(getContext(), "adChoiceLinkUrl is null", Toast.LENGTH_LONG).show();
                    return;
                }
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(linkUrl));
                final Context context = getContext();
                if (context == null) return;
                browserIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (browserIntent.resolveActivity(getContext().getPackageManager()) != null) {
                    startActivity(browserIntent);
                }
            }
        });
    }

}