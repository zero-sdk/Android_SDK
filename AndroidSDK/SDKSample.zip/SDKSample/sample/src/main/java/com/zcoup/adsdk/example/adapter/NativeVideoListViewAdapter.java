package com.zcoup.adsdk.example.adapter;

import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.zcoup.adsdk.example.R;
import com.zcoup.adsdk.example.SampleApplication;
import com.zcoup.adsdk.example.bean.News;
import com.zcoup.adsdk.example.fragment.NativeVideoListFragment;
import com.facebook.drawee.view.SimpleDraweeView;
import com.zcoup.video.core.ZCNativeVideo;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by huangdong on 16/8/18.
 */
public class NativeVideoListViewAdapter extends BaseAdapter {

    private List<News> newsList = new ArrayList<>();

    public NativeVideoListViewAdapter() {
    }


    @Override
    public int getCount() {
        return newsList.size();
    }


    @Override
    public News getItem(int i) {
        return newsList.get(i);
    }


    @Override
    public long getItemId(int i) {
        return i;
    }


    @Override
    public int getViewTypeCount() {
        return super.getViewTypeCount() + 1;
    }


    @Override
    public int getItemViewType(int position) {
        News news = newsList.get(position);
        if (news.isAds) {
            return 0;
        } else {
            return 1;
        }
    }

    @Override
    public View getView(int position, View contentView, ViewGroup viewGroup) {
        int itemType = getItemViewType(position);

        if (itemType == 0) {
            if (contentView == null) {
                contentView = View.inflate(SampleApplication.context, R.layout.native_video_layout, null);
            }

            TextView video_title = contentView.findViewById(R.id.video_title);
            RelativeLayout video_container = contentView.findViewById(R.id.video_container);
            SimpleDraweeView video_choice = contentView.findViewById(R.id.video_choice);
            TextView video_desc = contentView.findViewById(R.id.video_desc);
            TextView video_button = contentView.findViewById(R.id.video_button);

            News news = getItem(position);
            ZCNativeVideo ctNativeVideo = news.ctNativeVideo;

            video_title.setText(ctNativeVideo.getTitle());
            video_desc.setText(ctNativeVideo.getDesc());
            video_button.setText(ctNativeVideo.getButtonStr());
            video_choice.setImageURI(Uri.parse(ctNativeVideo.getAdChoiceIconUrl()));
            com.zcoup.video.view.NativeVideoAdView nativeVideoAdView = ctNativeVideo.getNativeVideoAdView();
            removeFromParent(nativeVideoAdView);
            video_container.addView(nativeVideoAdView);

            ctNativeVideo.registerForTracking(contentView, new com.zcoup.video.core.NativeVideoAdListener() {
                @Override
                public void videoStart() {
                    Log.i(NativeVideoListFragment.TAG, "videoStart: >>>>>>>>>>>>>>>>>>>>");
                }

                @Override
                public void videoFinish() {
                    Log.i(NativeVideoListFragment.TAG, "videoFinish: >>>>>>>>>>>>>>>>>>>>");
                }

                @Override
                public void videoClicked() {
                    Log.i(NativeVideoListFragment.TAG, "videoClicked: >>>>>>>>>>>>>>>>>>>>");
                }

                @Override
                public void videoError(Exception e) {
                    Log.i(NativeVideoListFragment.TAG, "videoError: >>>>>>>>>>>>>>>>>>>>" + e.getMessage());
                }
            });

            return contentView;
        } else {

            if (contentView == null) {
                contentView = View.inflate(SampleApplication.context, R.layout.item_advance_ad_list,
                        null);
            }

            SimpleDraweeView icon = contentView.findViewById(R.id.iv_icon);
            TextView tv_title = contentView.findViewById(R.id.tv_title);
            TextView tv_desc = contentView.findViewById(R.id.tv_desc);

            News news = getItem(position);
            icon.setImageURI(Uri.parse(news.iconUrl));
            tv_title.setText(news.title);
            tv_desc.setText(news.desc);

            return contentView;
        }

    }

    private static void removeFromParent(View v) {
        if (v == null) {
            return;
        }

        ViewParent vp = v.getParent();
        if (vp == null) {
            return;
        }

        if (vp instanceof AdapterView) {
            return;
        }
        ((ViewGroup) vp).removeAllViews();
    }

    public void setDate(List<News> aList) {
        if (aList != null) {
            newsList = aList;
        }
        notifyDataSetChanged();
    }

}

