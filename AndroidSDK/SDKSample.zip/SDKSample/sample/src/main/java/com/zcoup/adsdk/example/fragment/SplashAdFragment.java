package com.zcoup.adsdk.example.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.zcoup.adsdk.example.R;
import com.zcoup.adsdk.example.Splash2Activity;
import com.zcoup.adsdk.example.config.Config;
import com.zcoup.adsdk.example.listener.MyCTAdEventListener;
import com.zcoup.base.core.ZCNative;
import com.zcoup.base.core.ZcoupSDK;


public class SplashAdFragment extends Fragment {

    private TextView adStatusTextView;
    private Button loadButton;

    private static final String TAG = "SplashAdFragment";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_open_screen, null);
        initView(view);
        return view;
    }


    private void initView(View view) {

        adStatusTextView = (TextView) view.findViewById(R.id.statusLabel);

        loadButton = (Button) view.findViewById(R.id.loadButton);
        loadButton.setText("LOAD AD");
        loadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAd();
            }
        });

    }


    private void showAd() {
        log("Ready to load ads.");
        Splash2Activity.showMe(getContext());
    }



    public void loadAd() {

        log("Splash Ad Loading...");
        // 预加载
        ZcoupSDK.preloadSplashAd(getContext(), Config.slotIdNative, new MyCTAdEventListener() {
            @Override
            public void onReceiveAdSucceed(ZCNative result) {
                log("OpenScreen Ad Loaded.");
            }

            @Override
            public void onReceiveAdFailed(ZCNative result) {
                if (result != null && result.getErrorsMsg() != null)
                    log("onReceiveAdFailed errorMsg=" + result.getErrorsMsg());
            }

            @Override
            public void onAdClicked(ZCNative result) {

            }

            @Override
            public void onAdClosed(ZCNative result) {

            }
        });

    }


    private void log(final String s) {
        if (adStatusTextView != null) {
            Activity activity = getActivity();
            if (!isDetached() && activity != null) {
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        adStatusTextView.setText(s);
                    }
                });
            }

        }
        Log.w(TAG, "log: " + s);
    }
}
