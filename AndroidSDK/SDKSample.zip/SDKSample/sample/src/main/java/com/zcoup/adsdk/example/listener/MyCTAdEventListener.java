package com.zcoup.adsdk.example.listener;

import android.util.Log;
import android.widget.Toast;

import com.zcoup.base.callback.AdEventListener;
import com.zcoup.base.core.ZCNative;
import com.zcoup.base.vo.AdsVO;

public class MyCTAdEventListener extends AdEventListener {

    @Override
    public void onReceiveAdSucceed(ZCNative result) {
        showMsg("onReceiveAdSucceed");
    }

    @Override
    public void onReceiveAdVoSucceed(AdsVO result) {
        showMsg("onReceiveAdVoSucceed");
    }

    @Override
    public void onShowSucceed(ZCNative result) {
        showMsg("onShowSucceed");
    }

    @Override
    public void onReceiveAdFailed(ZCNative result) {
        showMsg(result.getErrorsMsg());
        Log.i("sdksample", "==error==" + result.getErrorsMsg());
    }

    @Override
    public void onLandPageShown(ZCNative result) {
        showMsg("onLandPageShown");
    }

    @Override
    public void onAdClicked(ZCNative result) {
        showMsg("onAdClicked");
    }

    @Override
    public void onAdClosed(ZCNative result) {
        showMsg("onAdClosed");
    }


    private void showMsg(String msg) {
        showToast(msg);
    }


    public static void showToast(String text) {
        // Toast.makeText(SampleApplication.context, text, Toast.LENGTH_SHORT).show();
    }


    private static Toast toast;

}
