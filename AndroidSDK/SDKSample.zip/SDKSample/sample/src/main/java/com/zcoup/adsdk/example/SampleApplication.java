package com.zcoup.adsdk.example;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.webkit.WebView;

import androidx.multidex.MultiDex;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.stetho.Stetho;
import com.squareup.leakcanary.LeakCanary;
import com.zcoup.adsdk.example.config.Config;
import com.zcoup.base.core.ZcoupSDK;

import java.lang.reflect.Field;

/*
 * Created by huangdong on 16/9/20.
 */
public class SampleApplication extends Application {

    @SuppressLint("StaticFieldLeak")
    public static Context context;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);


        //解决webview崩溃的代码
//        configWebViewCacheDirWithAndroidP();
    }

    private void configWebViewCacheDirWithAndroidP() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            String processName = getProcessName();
            if (!getPackageName().equals(processName)) {
                WebView.setDataDirectorySuffix(processName);
            }
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        if (BuildConfig.DEBUG) {
            if (LeakCanary.isInAnalyzerProcess(this)) {
                return;
            }
            LeakCanary.install(this); // TODO: 2016/12/28 检测内存泄露
        }
        context = this.getApplicationContext();

//      initialize the sdk
        ZcoupSDK.initialize(context, Config.slotIdReward);


//      initialize the fresco for sample
        Fresco.initialize(context);
        Stetho.initializeWithDefaults(this);

    }

}
