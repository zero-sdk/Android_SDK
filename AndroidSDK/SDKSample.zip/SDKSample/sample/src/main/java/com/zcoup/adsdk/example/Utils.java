package com.zcoup.adsdk.example;


import android.app.ActivityManager;
import android.content.Context;
import android.content.res.Resources;
import android.util.DisplayMetrics;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by huangdong on 16/8/18.
 */
public class Utils {

    //合并集合
    public static <GE> List<GE> combineAdAndContent(List<GE> localApks, List<GE> ads, int insertSteps) {
        List<GE> res = new ArrayList();
        res.addAll(localApks);

        int j = 0;
        while (j < ads.size()) {
            int newPosition = j * insertSteps + insertSteps + j;
            if (newPosition < res.size()) {
                res.add(newPosition, ads.get(j));
            } else {
                res.add(ads.get(j));
            }
            j++;
        }
        return res;
    }


    private static final String TAG = "FileHelper";

    // This utility function retrieves a file from assets folder and return
    // the content as string
    public static String getFileContent(Context activity, String fileName) {
        StringBuffer sb = new StringBuffer();

        try {
            InputStream is = activity.getResources().getAssets().open(fileName);
            BufferedReader bufferReader = new BufferedReader(
                    new InputStreamReader(is));
            String line;
            while ((line = bufferReader.readLine()) != null) {
                sb.append(line);
            }
            bufferReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        String fileContent = sb.toString();
        return fileContent;
    }

    /**
     * @return null may be returned if the specified process not found
     */
    public static String getProcessName(Context context, int pid) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> runningApps = am.getRunningAppProcesses();
        if (runningApps == null) {
            return null;
        }
        for (ActivityManager.RunningAppProcessInfo procInfo : runningApps) {
            if (procInfo.pid == pid) {
                return procInfo.processName;
            }
        }
        return null;
    }

    public static int dpToPx(int dp) {
        DisplayMetrics displayMetrics = Resources.getSystem().getDisplayMetrics();
        return (int) (dp * displayMetrics.density + .5f);
    }

}
