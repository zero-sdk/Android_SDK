//package com.zcoup.adsdk.example;
//
//import android.graphics.Color;
//import android.os.Build;
//import android.os.Bundle;
//import android.view.View;
//import android.webkit.WebSettings;
//import android.webkit.WebView;
//import android.webkit.WebViewClient;
//
//import androidx.annotation.Nullable;
//import androidx.appcompat.app.AppCompatActivity;
//
//import com.zcoup.base.cache.ImageInterceptor;
//import com.zcoup.base.cache.WebCacheManager;
//
///**
// * Created by jiantao.tu on 2020/10/12.
// */
//public class TestActivity extends AppCompatActivity {
//    private WebCacheManager webCacheManager = WebCacheManager.newInstance();
//
//    @Override
//    protected void onCreate(@Nullable Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        WebView webView = new WebView(this);
//        webCacheManager.addCacheInterceptor(new ImageInterceptor(this));
//        webView.setBackgroundColor(Color.TRANSPARENT);
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
//            webView.setWebContentsDebuggingEnabled(true);
//        }
//
//        WebSettings settings = webView.getSettings();
//        settings.setJavaScriptEnabled(true);
//        settings.setDomStorageEnabled(true);
//        settings.setDatabaseEnabled(true);
//        settings.setAppCacheMaxSize(1024 * 1024 * 16);//设置缓冲大小，设的是16M
//        String appCacheDir = getApplicationContext()
//                .getDir("cache", MODE_PRIVATE)
//                .getPath();
//        settings.setAppCachePath(appCacheDir);
//        settings.setAllowFileAccess(true);
//        settings.setAppCacheEnabled(true);
//        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
//        //允许加载http与https混合内容
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
//        }
//
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
//            settings.setMediaPlaybackRequiresUserGesture(false);
//        }
//
//
//        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
//        // api 11以上有个漏洞，要remove
//        webView.removeJavascriptInterface("searchBoxJavaBridge_");
//        webView.loadUrl("https://www.baidu.com");
//        setContentView(webView);
//    }
//}
