package com.zcoup.mediation.mopub;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import com.mopub.nativeads.CustomEventNative;
import com.mopub.nativeads.ImpressionTracker;
import com.mopub.nativeads.NativeErrorCode;
import com.mopub.nativeads.NativeImageHelper;
import com.mopub.nativeads.StaticNativeAd;
import com.zcoup.base.callback.AdEventListener;
import com.zcoup.base.core.ZCAdvanceNative;
import com.zcoup.base.core.ZCNative;
import com.zcoup.base.core.ZcoupSDK;
import com.zcoup.base.vo.AdsNativeVO;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ZCAdapterNative extends CustomEventNative {

    @Override
    protected void loadNativeAd(
        @NonNull Context context,
        @NonNull final CustomEventNativeListener customEventNativeListener,
        @NonNull Map<String, Object> localExtras, @NonNull Map<String, String> serverExtras) {
        final String adunitId;

        if (extrasAreValid(serverExtras)) {
            adunitId = serverExtras.get(ZCHelper.KEY_CT_SLOTID);
        } else {
            customEventNativeListener.onNativeAdFailed(
                NativeErrorCode.NATIVE_ADAPTER_CONFIGURATION_ERROR);
            return;
        }

        ZcoupSDK.initialize(context, adunitId);

        new ZcoupStaticNativeAd(context, adunitId, new ImpressionTracker(context),
            customEventNativeListener);
    }


    class ZcoupStaticNativeAd extends StaticNativeAd {
        private final ImpressionTracker mImpressionTracker;
        private final CustomEventNativeListener mCustomEventNativeListener;
        private ZCAdvanceNative advanceNative;


        public ZcoupStaticNativeAd(final Context context, String adunitId, final ImpressionTracker impressionTracker, CustomEventNativeListener customEventNativeListener) {
            mImpressionTracker = impressionTracker;
            mCustomEventNativeListener = customEventNativeListener;

            ZcoupSDK.getNativeAd(adunitId, context, new AdEventListener() {

                @Override
                public void onReceiveAdSucceed(ZCNative result) {
                    if (result == null) {
                        mCustomEventNativeListener.onNativeAdFailed(
                            NativeErrorCode.NETWORK_NO_FILL);
                        return;
                    }

                    advanceNative = (ZCAdvanceNative) result;

                    setIconImageUrl(advanceNative.getIconUrl());
                    setMainImageUrl(advanceNative.getImageUrl());

                    setTitle(advanceNative.getTitle());
                    setCallToAction(advanceNative.getButtonStr());
                    setText(advanceNative.getDesc());

                    setPrivacyInformationIconImageUrl(advanceNative.getAdChoiceIconUrl());
                    setPrivacyInformationIconClickThroughUrl(
                        advanceNative.getAdChoiceIconUrl());

                    final List<String> imageUrls = new ArrayList<>();

                    imageUrls.add(advanceNative.getImageUrl());
                    imageUrls.add(advanceNative.getIconUrl());

                    NativeImageHelper.preCacheImages(context, imageUrls,
                        new NativeImageHelper.ImageListener() {
                            @Override
                            public void onImagesCached() {
                                mCustomEventNativeListener.onNativeAdLoaded(
                                    ZcoupStaticNativeAd.this);
                            }


                            @Override
                            public void onImagesFailedToCache(NativeErrorCode errorCode) {
                                mCustomEventNativeListener.onNativeAdFailed(errorCode);
                            }
                        });
                }


                @Override
                public void onReceiveAdVoSucceed(AdsNativeVO result) {

                }


                @Override
                public void onInterstitialLoadSucceed(ZCNative result) {

                }


                @Override
                public void onReceiveAdFailed(ZCNative result) {
                    mCustomEventNativeListener.onNativeAdFailed(
                        NativeErrorCode.NETWORK_NO_FILL);
                }


                @Override
                public void onLandpageShown(ZCNative result) {

                }


                @Override
                public void onAdClicked(ZCNative result) {
                    notifyAdClicked();
                }


                @Override
                public void onAdClosed(ZCNative result) {

                }

            });
        }


        @Override
        public void prepare(final View view) {
            advanceNative.registeADClickArea(view);
            mImpressionTracker.addView(view, this);
        }


        @Override
        public void clear(@NonNull View view) {
            advanceNative.unRegisterAdClickArea();
            mImpressionTracker.removeView(view);
        }


        @Override
        public void recordImpression(final View view) {
            notifyAdImpressed();
        }


        @Override
        public void destroy() {
            mImpressionTracker.destroy();
        }
    }


    private boolean extrasAreValid(final Map<String, String> serverExtras) {
        return (serverExtras != null) && serverExtras.containsKey(ZCHelper.KEY_CT_SLOTID);
    }
}
